package cours.universite.universite.service;

import cours.universite.universite.modele.Etudiant;
import cours.universite.universite.repository.EtudiantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class EtudiantService implements InterfaceEtudiant{

    @Autowired
    private EtudiantRepository etudiantRepository;

    @Override
    public Etudiant findByNom(String nom) {
        Optional<Etudiant>etudiant=Optional.ofNullable(etudiantRepository.findByNom(nom));
        if (etudiant.isPresent())
            return etudiant.get();
        return null;
    }

    @Override
    public void savEtudiant(Etudiant etudiant) {
         etudiantRepository.save(etudiant);
    }

    @Override
    public List<Etudiant> FindALL() {
        return etudiantRepository.findAll();
    }

    @Override
    public Page<Etudiant> findPage(int numberPage) {
        Pageable pageable= PageRequest.of(numberPage,2);
        return etudiantRepository.findAll(pageable);
    }

    @Override
    public void supprimerEtudiant(long id) {
        etudiantRepository.deleteById(id);
    }

    @Override
    public Etudiant findById(long id) {
        Optional <Etudiant> etudiant=etudiantRepository.findById(id);
        if (etudiant.isPresent())
            return etudiant.get();
        return null;
    }
}
