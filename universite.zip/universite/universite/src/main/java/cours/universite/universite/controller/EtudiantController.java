package cours.universite.universite.controller;


import cours.universite.universite.modele.Etudiant;
import cours.universite.universite.service.InterfaceEtudiant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
//@RequestMapping("/")

public class EtudiantController {
    @Autowired
    private InterfaceEtudiant interfaceEtudiant;

//    @GetMapping("/etudiants")
//    public String index(Model model)
//    {
////        List<Etudiant> attribut =  interfaceEtudiant.FindALL();
//        model.addAttribute("attribut",interfaceEtudiant.FindALL());
//        return "index";
//    }

    @GetMapping("/etudiants")
    public String findAllpage(Model model){
        return FindAllPage(model,1);
    }

    @GetMapping("/etudiants/{numberPage}")
    public String FindAllPage(Model model, @PathVariable("numberPage") int currentPage)
    {
        Page<Etudiant>page=interfaceEtudiant.findPage(currentPage);
        int totalPages = page.getTotalPages();
        long totalItems =page.getTotalElements();
        List<Etudiant> etudiant=page.getContent();
        model.addAttribute("currentPage",currentPage);
        model.addAttribute("totalPages",totalPages);
        model.addAttribute("totalItems",totalItems);
        model.addAttribute("attribut",etudiant);
        return "index";
    }

    @PostMapping("/saveEtudiant")
    public String saveEtudiant(Etudiant etudiant,RedirectAttributes ra,Model model){

        interfaceEtudiant.savEtudiant(etudiant);

        ra.addFlashAttribute("message","L etudiant a ete ajouter avec succes" );

        return "redirect:/etudiants";
    }
//
//    @GetMapping("trouver/{username}")
//    @ResponseBody
//    public  Etudiant findByName(@RequestBody String nom)
//    {
//        return interfaceEtudiant.findByNom(nom);
//    }

    @GetMapping("/ShowFormulaireAjout")
    public String ShowFormulaireAjout(Model model){
        Etudiant etudiant= new Etudiant();
        model.addAttribute("etudiant",etudiant);
        model.addAttribute("pageTitre","Ajout d'un etudiant");
        model.addAttribute("bouton","Ajouter un etudiant");

        return "formulaireAjout";
    }


    @GetMapping("/deleteEtudiant/{id}")
    public String deleteEtudiant(@PathVariable("id") long id,RedirectAttributes ra){

        interfaceEtudiant.supprimerEtudiant(id);
        ra.addFlashAttribute("message","Etudiant dont l'id est "+id+"  a ete supprimer avec succees");
        return "redirect:/etudiants";
    }

    @GetMapping("/updateEtudiant/{id}")
    public String showUpdateForm(@PathVariable("id") long id,Model model,RedirectAttributes ra){
        Etudiant etudiant=new Etudiant();
        model.addAttribute("etudiant",etudiant);
        model.addAttribute("pageTitre","mise a jour d'un etudiant ID= "+id);
        model.addAttribute("bouton","Update");
        ra.addFlashAttribute("message","mise a jour avec succes" );
        return "formulaireAjout";
    }

}
