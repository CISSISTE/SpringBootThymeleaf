package cours.universite.universite.service;

import cours.universite.universite.modele.Etudiant;
import org.springframework.data.domain.Page;

import java.util.List;

public interface InterfaceEtudiant {
    Etudiant findByNom(String nom);
   void savEtudiant(Etudiant etudiant);
   List<Etudiant> FindALL();

   Page<Etudiant>findPage(int numberPage);

   void supprimerEtudiant(long id);

   public Etudiant findById(long id);

}
